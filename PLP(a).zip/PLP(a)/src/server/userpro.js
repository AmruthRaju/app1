const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ServerPort3 = new Schema(
  {
    school: { type: String },
    college: { type: String },
    degree: { type: String },
    selectedValue: { type: String },
    schoolyear: { type: Number },
    clgyear: { type: Number },
    degyear: { type: Number },
    location: { type: String },
    skills: { type: String },
    comname: { type: String },
    yof: { type: Number },
    userid: { type: String }
  },
  {
    collection: "plpuserpro3"
  }
);

module.exports = mongoose.model("ServerPort3", ServerPort3);
