import React, { Component } from "react";
import axios from "axios";
import NavComponent from "../User/Navbarcomponent/NavComponent";
import Card from "react-bootstrap/Card";
import { CardBody, CardHeader } from "reactstrap";
import { Redirect } from "react-router";

class profileuser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      logeduserdetails: {
        firstname: "",
        lastname: "",
        userType: "",
        email: "",
        password: ""
      },
      logeduser: sessionStorage.getItem("sessionId"),
      logeduseredudetail: {
        school: "",
        college: "",
        degree: "",
        selectedValue: "",
        schoolyear: "",
        clgyear: "",
        degyear: "",
        location: "",
        skills: "",
        comname: "",
        yof: "",
        userid: ""
      },
      calleditprofile: false
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:3001/Signup/" + this.state.logeduser)
      .then(response => {
        console.log(response.data);
        this.setState({
          logeduserdetails: response.data,
          redirect: true
        });
        console.log(this.state.logeduserdetails);
      })
      .catch(function(error) {
        console.log(error);
      });
    axios
      .get("http://localhost:3001/getUserData/" + this.state.logeduser)
      .then(response => {
        console.log(response.data);
        this.setState({
          logeduseredudetail: response.data
        });
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  handleChange = e => {
    this.setState({
      calleditprofile: true
    });
  };
  handleLogout = e => {
    sessionStorage.removeItem("sessionId");
    window.location.replace("/");
  };
  render() {
    let sessionId = sessionStorage.getItem("sessionId");
    console.log(sessionId);
    if (sessionId === undefined || sessionId === null) {
      return <Redirect to="/profileuser" />;
    }
    return (
      <div className="content">
        <NavComponent />
        <div className="row">
          <div className="col-lg-4" />

          <div className="col-lg-4">
            <Card>
              <CardBody>
                <font size="2" className="h9 text-muted">
                  Name: {this.state.logeduserdetails.firstname}{this.state.logeduserdetails.lastname}
                </font>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <font size="2" className="h9 text-muted">
                  Email: {this.state.logeduserdetails.email}
                </font>
              </CardBody>
            </Card>
          </div>

          {/* starting =====================================================================================*/}
          <div className="col-lg-4">
          <br/>
          <br/>
          <br/>
            <Card>
              <CardHeader>
                <h3>Location</h3>
              </CardHeader>
              <CardBody>
                <font size="2" className="h9 text-muted">
                  Location: {this.state.logeduseredudetail.location}
                </font>
              </CardBody>
              {/* <CardFooter>
                <a href={"/editprofile"} className="btn btn-warning ">
                  Edit Profile
                </a>
              </CardFooter> */}
            </Card>
          </div>
          <div className="col-lg-4">
            <Card>
              <CardHeader>
                <h3>Education</h3>
              </CardHeader>
              <CardBody>
                <font size="2" className="h9 text-muted">
                  school: {this.state.logeduseredudetail.school}
                  <br />
                  school Year: {this.state.logeduseredudetail.schoolyear}
                  <br />
                  College: {this.state.logeduseredudetail.college}
                  <br />
                  College Year: {this.state.logeduseredudetail.clgyear}
                  <br />
                  Degree: {this.state.logeduseredudetail.degree}
                  <br />
                  Degree Year: {this.state.logeduseredudetail.degyear}
                </font>
              </CardBody>
              {/* <CardFooter>
                <a href={"/editprofile"} className="btn btn-warning ">
                  Add Education
                </a>
              </CardFooter> */}
            </Card>
            <br />
            <hr />
            <Card>
              <CardHeader>
                <h3>Skills</h3>
              </CardHeader>
              <CardBody>
                <font size="2" className="h9 text-muted">
                  Skills:{this.state.logeduseredudetail.skills}
                </font>
                <br />
              </CardBody>
              {/* <CardFooter>
                <a href={"/addskill"} className="btn btn-success ">
                  Add Skill
                </a>
              </CardFooter> */}
            </Card>
          </div>
          <div />
        </div>
        {this.state.logeduseredudetail.selectedValue === "experienced" ? (
          <Card>
            <br />
            <hr />
            <CardHeader>
              <h3>Experience</h3>
            </CardHeader>
            <CardBody>
              <font size="2" className="h9 text-muted">
                Company Name:
                {this.state.logeduseredudetail.comname}
                Year Of Experience: {this.state.logeduseredudetail.yof}
              </font>
            </CardBody>
            {/* <CardFooter>
              <a href={"/addexperience"} className="btn btn-primary">
                Add Experience
              </a>
            </CardFooter> */}
          </Card>
        ) : null}
        <hr />
        <div className="text-center">
          <input
            type="button"
            value="Edit Profile"
            className="btn btn-warning"
            onClick={this.handleChange}
          />
        </div>
        <div className="col-lg-10">
          <input
            type="button"
            value="Logout"
            className="btn btn-danger"
            onClick={this.handleLogout}
          />
        </div>
        {this.state.calleditprofile ? <Redirect to="/Edituserprofile" /> : null}
      </div>
    );
  }
}

export default profileuser;
