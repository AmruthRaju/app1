import React from "react";
import axios from "axios";
import { Redirect } from "react-router";

class userprofile extends React.Component {
  constructor(props) {
    super(props);

    this.onChangeSchool = this.onChangeSchool.bind(this);
    this.onChangeCollege = this.onChangeCollege.bind(this);
    this.onChangeDegree = this.onChangeDegree.bind(this);
    this.onSelection = this.onSelection.bind(this);
    this.onChangeSyear = this.onChangeSyear.bind(this);
    this.onChangeCyear = this.onChangeCyear.bind(this);
    this.onChangeDyear = this.onChangeDyear.bind(this);
    this.onChangeLocation = this.onChangeLocation.bind(this);
    this.onChangeSkills = this.onChangeSkills.bind(this);
    this.onChangeCompname = this.onChangeCompname.bind(this);
    this.onChangeYearOfExp = this.onChangeYearOfExp.bind(this);

    this.state = {
      school: "",
      college: "",
      degree: "",
      selectedValue: "student",
      schoolyear: "",
      clgyear: "",
      degyear: "",
      location: "",
      skills: "",
      comname: "",
      yof: "",
      userid: sessionStorage.getItem("sessionId")
    };
  }

  onChangeSchool(e) {
    this.setState({
      school: e.target.value
    });
    console.log(this.state.school);
  }

  onChangeCollege(e) {
    this.setState({
      college: e.target.value
    });
  }

  onChangeDegree(e) {
    this.setState({
      degree: e.target.value
    });
  }

  onSelection(event) {
    this.setState({
      selectedValue: event.target.value
    });
  }
  onChangeSyear(e) {
    this.setState({
      schoolyear: e.target.value
    });
  }
  onChangeCyear(e) {
    this.setState({
      clgyear: e.target.value
    });
  }

  onChangeDyear(e) {
    this.setState({
      degyear: e.target.value
    });
  }
  onChangeLocation(e) {
    this.setState({
      location: e.target.value
    });
  }
  onChangeSkills(e) {
    this.setState({
      skills: e.target.value
    });
  }
  onChangeCompname(e) {
    this.setState({
      comname: e.target.value
    });
  }
  onChangeYearOfExp(e) {
    this.setState({
      yof: e.target.value
    });
  }

  onSubmit = e => {
    e.preventDefault();
    console.log(this.state.userid);
    alert("Details updated successfully!!");

    console.log(this.state);
    const profile = {
      school: this.state.school,
      college: this.state.college,
      degree: this.state.college,
      selectedValue: this.state.selectedValue,
      schoolyear: this.state.schoolyear,
      clgyear: this.state.clgyear,
      degyear: this.state.degyear,
      location: this.state.location,
      skills: this.state.skills,
      comname: this.state.comname,
      yof: this.state.yof,
      userid: sessionStorage.getItem("sessionId")
    };
    console.log(profile);
    alert("gfg");
    axios
      .post("http://localhost:3001/userprofile", profile)
      .then(function (response) {
        console.log(response.data);
        window.location.replace("/profileuser");

      });
    this.setState({
      name: "",
      status: "",
      redirect: true
    });
  };

  render() {
    let sessionId = sessionStorage.getItem("sessionId");
    if (sessionId === undefined || sessionId === null) {
      return <Redirect to="/login" />;
    }
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    // if (redirect) {
    //   return <Redirect to="/profileuser" />;
    // }
    return (
      <div className="container">
        <h1 className="text-primary"> Profile</h1>
        <form onSubmit={this.onSubmit}>
          <div className="col-lg-4">
            <br />
            <br />
          </div>
          <div className="col-lg-4">
            <div className="form-group">
              <label className="text-primary">
                <h3> School </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="school"
                required
                value={this.state.school}
                onChange={this.onChangeSchool}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3>College </h3>
              </label>
              <input
                type="text"
                max="4"
                className="form-control"
                placeholder="college"
                required
                value={this.state.college}
                onChange={this.onChangeCollege}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3> Degree </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="degree"
                value={this.state.degree}
                onChange={this.onChangeDegree}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3> User Type:</h3>
              </label>
              &nbsp;
              <select
                className="form-control"
                value={this.state.selectedValue}
                onChange={this.onSelection}
                required
              >
                <option selected value="student">
                  Student
                </option>
                <option value="experienced">Experienced</option>
              </select>
            </div>
            <br /> <br />
            {/* <div className="form-group">
              <input type="submit" value="Signup" className="btn btn-primary" />
            </div> */}
          </div>
          <div className="col-lg-4">
            <div className="form-group">
              <label className="text-primary">
                <h3> School - Year </h3>
              </label>
              <input
                type="number"
                className="form-control"
                placeholder="school-year"
                required
                maxLength="4"
                value={this.state.schoolyear}
                onChange={this.onChangeSyear}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3> College - Year </h3>
              </label>
              <input
                type="number"
                maxLength="4"
                className="form-control"
                placeholder="College - Year"
                required
                value={this.state.clgyear}
                onChange={this.onChangeCyear}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3> Degree - Year </h3>
              </label>
              <input
                type="number"
                maxLength="4"
                className="form-control"
                placeholder="degree-year"
                required
                value={this.state.degyear}
                onChange={this.onChangeDyear}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3>Location </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="location"
                required
                value={this.state.location}
                onChange={this.onChangeLocation}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3>Skills </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="Skills"
                required
                value={this.state.skills}
                onChange={this.onChangeSkills}
              />
            </div>
          </div>
          {this.state.selectedValue === "experienced" ? (
            <div>
              <div className="form-group">
                <label className="text-primary">
                  <h3>Company Name</h3>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Company Name"
                  required
                  value={this.state.comname}
                  onChange={this.onChangeCompname}
                />
              </div>
              <div className="form-group">
                <label className="text-primary">
                  <h3>Year Of Experience </h3>
                </label>
                <input
                  type="number"
                  maxLength="2"
                  className="form-control"
                  placeholder="Experience"
                  required
                  value={this.state.yof}
                  onChange={this.onChangeYearOfExp}
                />
              </div>
            </div>
          ) : null}
          <div className="form-group">
            <input type="submit" value="submit" className="btn btn-primary" />
          </div>
        </form>
      </div>
    );
  }
}

export default userprofile;
