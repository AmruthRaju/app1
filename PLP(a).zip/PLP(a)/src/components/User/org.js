import React from 'react'
import Card from 'react-bootstrap/Card';
import { CardBody, CardHeader } from 'reactstrap';
import axios from 'axios';


class org extends React.Component {
  constructor() {
    super()
    this.state = { jobpost: [] }

  }

  baseurl = "http://localhost:3001/PostJob";
  getPost = () => {
    axios.get(this.baseurl).then((response) => {
      this.setState({ jobpost: response.data })
      console.log(this.state.jobpost)
    });
  }

  addjobPost = (jobpost) => {
    console.log(jobpost)
    axios.post(this.baseurl, jobpost).then((response) => {
      this.getPost();
      alert("Post added")
    })
  }

  componentDidMount() {
    this.getPost();
  }

  jobpost = React.createRef();

  handleAddJobPost = () => {
    let contObject = { jobpost: this.jobpost.current.value }
    this.addjobPost(contObject)
  }

  render() {
    return (
      <div>
        <h1> Post a Job</h1>
        <div className="jumbotron" >
          <div className="container">
            <div className="row">

              <Card>
                <CardHeader>
                  <form className="form-group">
                    <textarea type="text" className="form-control" placeholder="Post Here....." ref={this.jobpost}>
                    </textarea>
                  </form>
                </CardHeader>
                <CardBody>
                  <button className="btn btn-outline-dark" onClick={this.handleAddJobPost}>Add Job Post</button>
                </CardBody>
              </Card>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default org;