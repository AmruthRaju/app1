import React from "react";
import axios from "axios";
import { Redirect } from "react-router";
import Menu from "../core/Menu";
class Login2 extends React.Component {
  constructor(props) {
    super(props);
    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      email: "",
      password: "",
      login2: [],
      redirect: "",
      flag: false
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:3001/register")
      .then(response => {
        this.setState({
          login2: response.data
        });
        console.log(this.login);
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  onSubmit(e) {
    e.preventDefault();
    this.enteredUsername = this.state.email;
    this.enteredPassword = this.state.password;
    console.log(this.state.login2.length);
    for (let i = 0; i < this.state.login2.length; i++) {
      if (
        this.enteredUsername === this.state.login2[i].email &&
        this.enteredPassword === this.state.login2[i].password
      ) {
        this.setState({
          flag: true,
          redirect: true
        });
        this.flag2 = true;
        break;
      } else {
        this.setState({
          flag: false,
          redirect: false
        });
        this.flag2 = false;
      }
    }
    console.log("value=>" + this.state.redirect);
    if (this.flag2 === false) {
      alert("Wrong username and password");
    }
  }
  onChangeUsername(e) {
    this.setState({
      email: e.target.value
    });
  }
  onChangePassword(e) {
    this.setState({
      password: e.target.value
    });
  }

  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      alert("Login Successfully");
      return <Redirect to="/org" />;
    
    }
    return (
      <div className="container">
        <Menu />
        <div className="col-lg-4">
          <br />
          <br />
          <h2 className="text-center text-primary">Welcome Back</h2>
          <form onSubmit={this.onSubmit}>
            <br />

            <div className="form-group">
              <label className="text-primary">
                <h3>
                  <i className="far fa-envelope" />
                  &nbsp;Email
                </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="Email"
                value={this.state.email}
                onChange={this.onChangeUsername}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3>
                  <i className="fas fa-lock" />
                  &nbsp;Password{" "}
                </h3>
              </label>
              <input
                type="password"
                className="form-control"
                placeholder="Password"
                value={this.state.password}
                onChange={this.onChangePassword}
              />
            </div>

            <div className="form-group">
              <input type="submit" value="Signup" className="btn btn-primary" />
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Login2;
