const express = require("express");
const app = express();
const ServerPortRouter = express.Router();
const nodemailer = require("nodemailer");
const nodemSmtpTransport = require('nodemailer-smtp-transport');

const ServerPort = require("./app");
const ServerPort2 = require("./app1");
const ServerPort3 = require("./userpro");
const JobPostServerPort = require("./jobs");

var smtpTransport = nodemailer.createTransport(nodemSmtpTransport({
  service: "gmail",
  auth: {
    // user: "kumarnihal900@gmail.com",
    // pass: "Nihal@9040"
    user: "rajabhinav199@gmail.com",
    pass: "Abhinav@12345"
  }
}));

var mailOptions, link;

ServerPortRouter.route("/Signup").post(function (req, res) {

  const serverport = new ServerPort(req.body);

  link = "http://" + req.get('host') + "/verify?id=456465";
  mailOptions = {
    to: req.body.email,
    subject: "Please confirm your Email account",
    html: "Hello,<br> Please Click on the link to verify your email.<br><a href=" + link + ">Click here to verify</a>"
  }
  smtpTransport.sendMail(mailOptions, function (error, response) {
    if (error) {
      res.end("Error");
    } else {
      res.end("Sent");
    }
  });

  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});

ServerPortRouter.route("/register").post(function (req, res) {
  const serverport = new ServerPort2(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});

ServerPortRouter.route('/PostJob').post(function (req, res) {
  const jobserverport = new JobPostServerPort(req.body)
  jobserverport.save().then(jobserverport => {
    res.json('Job Post added Successfully')
  })
    .catch(err => {
      res.status(400).send("unable to save to database")
    })
})

ServerPortRouter.route('/PostJob').get(function(req,res){
  JobPostServerPort.find(function(err,serverports){
      if(err){
          console.log(err)
      } else{
          res.json(serverports)
      }
  })
})

ServerPortRouter.route("/userprofile").post(function (req, res) {
  const serverport = new ServerPort3(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});
// ServerPortRouter.route("/contacts").get(function(req, res) {
//   ServerPort.find(function(err, serverports) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(serverports);
//     }
//   });
// });

ServerPortRouter.route("/Signup").get(function (req, res) {
  ServerPort.find(function (err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});

ServerPortRouter.route("/register").get(function (req, res) {
  ServerPort2.find(function (err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/userprofile").get(function (req, res) {
  ServerPort3.find(function (err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/getUserData/:id").get(function (req, res) {
  ServerPort3.findOne({ userid: req.params.id }, function (err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/Signup/:id").get(function (req, res) {
  ServerPort.findOne({
    _id: req.params.id
  }, function (err, serverports) {
    if (err) {
      console.log(err);
    } else {
      console.log(serverports)
      res.json(serverports);
    }
  });
});

ServerPortRouter.route("/Edituserprofile/:id").put(function (req, res) {
  console.log(req.body);
  ServerPort3.findOneAndUpdate({ userid: req.params.id }, req.body, function (
    err,
    serverports
  ) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  }).catch(err => {
    res.status(400).send("unable to save to database");
  });
});
module.exports = ServerPortRouter;
