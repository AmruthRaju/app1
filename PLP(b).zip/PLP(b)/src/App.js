import React from "react";
import Router from "./components/Router";
import { BrowserRouter } from "react-router-dom";

import "./App.css";

const App = () => (
  <div className="container">
    <BrowserRouter>
      <Router />
    </BrowserRouter>
  </div>
);

export default App;
