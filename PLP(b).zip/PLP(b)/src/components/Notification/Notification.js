import React from 'react'
import Promoted1 from './Promoted1'
import Promoted2 from './Promoted2';
import NotificationData from './NotificationData';
import notiDummyData from './Notification-dummy-data';
import NavComponent from "../User/Navbarcomponent/NavComponent";


class Notifications extends React.Component {
    state = { notiDummyData };
    render() {
        return (
            <div>
                <NavComponent />
                <div class="container">
                    <div className="row">
                        <div className="col-lg-3">
                            <Promoted1 />
                        </div>
                        <div className="col-lg-6">
                            {this.state.notiDummyData.map((noti, i) => {
                                return (
                                    <NotificationData key={i} noti={noti} />)
                            })}
                        </div>
                        <div className="col-lg-3">
                            <Promoted2 />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Notifications