import React, { Component } from "react";
import { Route, Switch } from "react-router-dom";
import Home from "./core/Home";
import Signup from "./User/Signup";
import Login from "./User/Login";
import userprofile from "./User/userprofile";
import register from "./User/register";
import Login2 from "./User/Login2";
import profileuser from "./User/profileuser";
import org from "./User/org";
import Edituserprofile from "./User/Edituserprofile";
import Notification from "./Notification/Notification"
import Jobs from "./Jobs/Jobs"
import ProfileDisplay from "./Jobs/User/viewjobs";

class Router extends Component {
  render() {
    return (
      <div>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/Signup" component={Signup} />
          <Route exact path="/Login" component={Login} />
          <Route exact path="/register" component={register} />
          <Route exact path="/userprofile" component={userprofile} />
          <Route exact path="/profileuser" component={profileuser} />
          <Route exact path="/Login2" component={Login2} />
          <Route exact path="/org" component={org} />
          <Route exact path="/Edituserprofile" component={Edituserprofile} />
          <Route exact path="/notifications" component={Notification} />
          <Route exact path="/network" component={Jobs} />
          <Route exact path="/viewjobs" component={ProfileDisplay} />

        </Switch>
      </div>
    );
  }
}

export default Router;
