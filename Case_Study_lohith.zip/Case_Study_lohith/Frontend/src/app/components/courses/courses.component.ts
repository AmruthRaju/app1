import { Component, OnInit } from "@angular/core";
import { Validators, FormBuilder, FormGroup } from "@angular/forms";
import { UserService } from "src/app/services/user.service";
import { Course } from "src/app/model/user";

@Component({
  selector: "app-courses",
  templateUrl: "./courses.component.html",
  styleUrls: ["./courses.component.css"]
})
export class CoursesComponent implements OnInit {
  addForm: FormGroup;
  submitted: boolean = false;
  course: Course[] = [];
  duration: string;
  invalidName: boolean = false;

  constructor(private formbuilder: FormBuilder, private userservice: UserService) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      courseName: ["", Validators.required],
      courseDuration: ["", Validators.required],
      coursePrice: ["", Validators.required]
    });
    this.userservice.getCourses().subscribe(data => {
      this.course = data;
      console.log(data);
    });
  }

  getCourse() {
    this.userservice.getCourses().subscribe(data => {
      this.course = data;
      console.log(data);
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    this.userservice.createCourse(this.addForm.value).subscribe(data => {
      alert("Course has been added successfully!! ");
    });

    this.getCourse();
  }


  // in ts file
  getDuration(cors) {
    console.log(cors.txtName);
    this.invalidName = false;
    this.duration = undefined;
    for (let i of this.course) {
      if (cors.txtName == i.courseName) {
        this.duration = i.courseDuration;
      }
    }
    if (this.duration == undefined) {
      this.invalidName = true;
    }
  }
}
