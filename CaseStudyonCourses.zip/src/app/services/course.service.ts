import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Course } from '../model/course';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  baseUrl: string = "http://localhost:3000/courses";
  constructor(private http: HttpClient) { }

  getCourse() {
    return this.http.get<Course[]>(this.baseUrl);;
  }

  addCourse(course:Course){
    return this.http.post(this.baseUrl,course);
  }
}
