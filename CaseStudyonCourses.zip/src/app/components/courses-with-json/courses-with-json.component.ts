import { Component, OnInit } from '@angular/core';
import { Course } from 'src/app/model/course';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-courses-with-json',
  templateUrl: './courses-with-json.component.html',
  styleUrls: ['./courses-with-json.component.css']
})
export class CoursesWithJSONComponent implements OnInit {

  courses: Course[];
  constructor(private courseService: CourseService) { }

  ngOnInit() {
    this.courseService.getCourse().subscribe(data => {
      this.courses = data;
    });
  }
}
