import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CourseService } from 'src/app/services/course.service';
import { Course } from 'src/app/model/course';
import { NgForm } from '@angular/forms';
import { stringify } from '@angular/core/src/util';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  cDuration:number;
  courses: Course[];
  constructor(private router: Router, private courseService: CourseService) { }

  ngOnInit() {
    this.courseService.getCourse().subscribe(data => {
      this.courses = data;
    });

  }

  getCDuration(cname:string) {
    // alert(cname);
    for(let c of this.courses){
      if(c.name==cname)
      {
        // alert(c.name);
        this.cDuration=c.duration;
      }
    }
  }
}
