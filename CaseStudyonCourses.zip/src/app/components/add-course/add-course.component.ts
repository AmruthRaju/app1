import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { CourseService } from 'src/app/services/course.service';


@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean =false;
  constructor(private formbuilder:FormBuilder, private courseService:CourseService) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      id:['', Validators.required],
      name: ['', Validators.required],
      price: ['', Validators.required],
      duration: ['', Validators.required]
    })
  }

  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }

    this.courseService.addCourse(this.addForm.value).subscribe();
  }

}
