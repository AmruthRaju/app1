import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CoursesComponent } from './components/courses/courses.component';
import { CoursesWithJSONComponent } from './components/courses-with-json/courses-with-json.component';
import { AddCourseComponent } from './components/add-course/add-course.component';

const routes: Routes = [
  {path:'courses', component:CoursesComponent},
  {path:'addCourses', component:AddCourseComponent},
  {path:'coursesWithJSON', component:CoursesWithJSONComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
