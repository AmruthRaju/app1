import { Injectable } from '@angular/core';

import { ToDo } from '../model/todo';
import{HttpClient}from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ServiceTodoService {

  baseUrl = "http://localhost:3000/todos"
  constructor(private http:HttpClient) { }



  getTodo() {
    return this.http.get<ToDo[]>(this.baseUrl )
  } 

   addtoJson(todo: ToDo) {

    return this.http.post(this.baseUrl, todo)

  }

  deletetoJson(id) {
    return this.http.delete(this.baseUrl + "/" + id)
  }
updateInJson(updateTodo:ToDo){
  return this.http.put<ToDo[]>(this.baseUrl+"/"+updateTodo.id,updateTodo)

}

gettodoById(id: number) {
  return this.http.get<ToDo>(this.baseUrl + "/" + id)
} 


}








