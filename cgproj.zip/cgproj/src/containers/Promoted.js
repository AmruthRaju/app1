import React from 'react';
import styled from 'styled-components';

function Promoted() {
  const PromotedStyles = styled.div`
    width: 550px;
    height: 200px;
    border: 1px solid #CACCCE;
    padding: 0;
    margin: 0 15px;
    background-color: #FFFFFF;
    box-shadow: -2px 4px #D0D3D6;

    h1 {
      float: left;
      margin 15px 15px;
      color: #CACCCE;
    }
  `;

  return (
    <PromotedStyles className='promoted'>
      <div>
        <div >
          <br />&nbsp;
          <img width="100px" className="img-circle" width="40px" height="40px" src={require('../images/download.jpeg')} />
          &nbsp;&nbsp;
            <span>Capgemini</span>
          <br />
          &nbsp;
          <span className="MyLinkText">Our application page at FasterCapital has specific instructions such as ... and swot analysis,

 photos of the startup team including their LinkedIn profile.</span><br /><br />
&nbsp;
          <button className="btn btn-success" >view jobs</button>



        </div>

      </div>
    </PromotedStyles>
  )
}

export default Promoted;