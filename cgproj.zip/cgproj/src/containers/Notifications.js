import React from 'react'

import Promoted  from './Promoted'

import Promoted1  from './Promoted1'
import Promoted2 from './Promoted2';
import Promoted3 from './promoted3';


class Notifications extends  React.Component{

    render()
    {
        return(
<div >



  <div className="row">
          <div className="col-xs-3 ">

          <Promoted1/>


          </div>

          <div className="col-xs-6">

          <Promoted/><br/>
          <Promoted3/>

     

          </div>
          

          <div className="col-xs-3 text-right">

         <Promoted2/>

            
          </div>

  </div>     

       

    <footer>

  

      <div class="row">

        <div class="col-lg-12">

          <span>

            <h5>Copy Right &cpy; &nbsp;&nbsp;&nbsp;&nbsp;</h5>&nbsp;

           

          </span>

        </div>

      </div>

  

  </footer>

  </div>


        )

    }

}

export default Notifications