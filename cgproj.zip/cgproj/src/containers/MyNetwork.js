import React, { Component } from "react";

class MyNetwork extends Component {
    render() {
        return (
            <div>
                MyNetwork
        </div>
        );
    }
}

export default MyNetwork;