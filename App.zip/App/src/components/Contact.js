import React from "react";
import AddContact from "./AddContact";
import ShowContact from "./ShowContact";
import axios from 'axios';

class Contact extends React.Component {

  constructor(){
  super()
  this.state={contacts:[]}
}

baseURL="http://localhost:4000/serverport";
componentDidMount() {this.getContacts()}
getContacts=()=>{
axios.get(this.baseURL).then((response)=>{
this.setState({contacts:response.data})
})
}

addContact = (serverport) =>{
  axios.post("http://localhost:4000/serverport/add", serverport).then((response)=>{
    this.getContacts();
    alert('Contact Added !!!');
  });
}

deleteContact = (id) => {
  alert('contact id: '+ id)
  axios.delete(this.baseURL + id).then((res) => {
    this.getContacts();},(err=>{
      this.setState({errors:err})
    
    })
  )
};

  render() {
    return (
        <div>
        <h1 className="page-header">Manage Contacts</h1> 
        <ShowContact contacts={this.state.contacts} deleteContact={this.deleteContact}/>
        <AddContact addContact={(serverport)=> this.addContact(serverport)}/>
        
        </div>
    );
  }
}
export default Contact