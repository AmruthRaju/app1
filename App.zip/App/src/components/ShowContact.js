import React from "react";

class ShowContact extends React.Component {
  render() {
    const contacts = this.props.contacts;

    return (
      <div>
          <h1> Display Contacts</h1>
        <table className="table table-striped table-bordered">
          <thead className="thead-dark">
            <tr>
              <th>ID</th>
              <th>Contact Name</th>
              <th>Contact Number</th>
              <th>Delete</th>
            </tr>
          </thead>

          <tbody>
            {contacts.map(contact => (
              <tr key={contact}>
              <td>{contact.id}</td>
                <td>{contact.contactname}</td>
                <td>{contact.contactnumber}</td>
                <td>
                    <button onClick={() => this.props.deleteContact(contact.id)} className="btn btn-danger">X</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default ShowContact;
