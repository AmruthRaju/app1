const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for ServerPort
const ServerPort = new Schema({
  contactname: {
    type: String
  },
  contactnumber: {
      type: Number
  }
},
{
    collection: 'showcontact'
});

module.exports = mongoose.model('ServerPort', ServerPort);