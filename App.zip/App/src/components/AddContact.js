import React from "react";

class AddContact extends React.Component {
  //step 1 - create 2 reference variables
  contactname = React.createRef();
  contactnumber = React.createRef();
// step 4 - define and Call the function added in step 3
  handleAddContact = () => {
    let constObject = {
      contactname: this.contactname.current.value,
      contactnumber: this.contactnumber.current.value
    };
    this.props.addContact(constObject);
  };
  render() {
    return (
      <div className="well">
        <h1>Add Contact</h1>
        <form>
          {/* step 2 - attach ref variables to input field  */}
          Contact Name <input ref={this.contactname} />
          <br />
          Contact Number <input ref={this.contactnumber} />
          <br />
          {/* step 3 - add a button with onclick to add */}
          <button onClick={this.handleAddContact} className="btn btn-success">
            Add Contact
          </button>
        </form>
      </div>
    );
  }
}
export default AddContact;
