import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import './App.css';
import Contact from './components/Contact';
import Login from './components/Login';


class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
        <div className ="row">
        <div className="col-md-12">
        <nav className="navbar navbar-expand-lg navbar-light bg-dark">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            Brand
          </Link>
        </div>
        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav">
            <li className="active">
              <Link to="/">
                Home
                <span className="sr-only"> </span>
              </Link>
              </li>
              <li><Link to={'/Contact'}>Contact</Link></li>
              <li><Link to={'/Login'}>Login</Link></li>
          
        
        <hr />
        <Switch>
            <Route exact path='/Contact' component={ Contact } />
            <Route exact path='/Login' component={ Login } />
      
        </Switch>
        
        </ul>
        </div>
      </nav> </div>
      </div>
      </div>
    </Router>
    );
  }
}

export default App;
